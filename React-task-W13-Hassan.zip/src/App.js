import { useState } from "react";
import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import { Menu, Moon, Sun, X } from "lucide-react";
import LoginForm from "./pages/LoginForm";
import Register from "./pages/Register";
import Products from "./pages/Products";
import "./App.css";
import NotFound from "./pages/not-found";
import Home from "./pages/Home";
import ProductDetails from "./pages/ProductDetails";
import { useTheme } from "./context/Theme/useTheme";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "./store/authSlice";
// import { logout } from "../../store/authSlice";
function App() {
  const [isNavOpen, setIsNavOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const user = useSelector((state) => state.auth.user);
  const dispatch = useDispatch();
  return (
    <BrowserRouter>
      <header>
        <div className="container header__container">
          <h1 className="h1">DKUST</h1>
          <button
            className="theme-toggle"
            type="button"
            aria-label={`Switch to ${theme === "light" ? "dark" : "light"} mode`}
            onClick={toggleTheme}
          >
            {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
          </button>
          <button
            className="nav-toggle"
            type="button"
            aria-label={isNavOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={isNavOpen}
            onClick={() => setIsNavOpen((isOpen) => !isOpen)}
          >
            {isNavOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <nav className={`header__nav ${isNavOpen ? "is-open" : ""}`}>
            <NavLink
              to="home"
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              HOME
            </NavLink>
            <NavLink
              to="/a"
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              ABOUT
            </NavLink>
            <NavLink
              to="/p"
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              PORTFOLIO
            </NavLink>
            <NavLink
              to="products"
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              PRODUCTS
            </NavLink>
            <NavLink
              to="/s"
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              SERVICES
            </NavLink>
            <NavLink to="/b">BLOG</NavLink>
            <NavLink to="/r">RESOURCES</NavLink>
            <NavLink to="/q">QUIZ</NavLink>
            <NavLink to="/c">CONTACT</NavLink>
            <NavLink to="login" id="login">
              LOGIN
            </NavLink>
            <NavLink to="register" id="login">
              REGISTER
            </NavLink>
          </nav>
        </div>
      </header>
      <Routes>
        <Route path="home" element={<Home />} />
        <Route path="login" element={<LoginForm />} />
        <Route path="register" element={<Register />} />
        <Route path="products" element={<Products />} />
        <Route path="/products/:id" element={<ProductDetails />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
