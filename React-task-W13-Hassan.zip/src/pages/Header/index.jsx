const Header = () => {
  return (
    <header>
      <h1 className="h1">DKUST</h1>

      <nav className="header__nav">
        <a href="Home.html">HOME</a>
        <a href="#">ABOUT</a>
        <a href="#">PORTFOLIO</a>
        <a href="#">SERVICES</a>
        <a href="#">BLOG</a>
        <a href="#">RESOURCES</a>
        <a href="#">QUIZ</a>
        <a href="#">CONTACT</a>
        <a href="login.html" id="login">LOGIN</a>
      </nav>
    </header>
  );
};

export default Header;