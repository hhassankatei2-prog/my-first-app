

import { useState } from "react";
import { LuLayoutGrid } from "react-icons/lu";
import { BsGridFill, BsListUl } from "react-icons/bs";
import ProductCardGrid from "../../components/ProductCardGrid";
import ProductCardList from "../../components/ProductCardList";
import {
  StyleDivHeader,
  PageContainer,
  FilterBar,
  CategoryButtons,
  ViewToggle,
  ResultsCount,
  ProductsGrid,
  ProductsList,
  HrMargin,
  DivContainer,
  BackgroundColor,
} from "./style";
import Footer from "../Footer";

const productsArray = [
  {
    id: 1,
    name: "AI Analytics Dashboard",
    category: "Software",
    description:
      "Real-time analytics powered by machine learning. Monitor KPIs, detect anomalies, and get predictive insights from your data with an intuitive drag-and-drop interface.",
    price: 299,
    rating: 4.8,
    reviewsCount: 124,
    badge: "Best Seller",
    cardColor:"#1A3A6E",
  },
  {
    id: 2,
    name: "RoboArm Pro X1",
    category: "Robotics",
    description:
      "Industrial-grade robotic arm with 6 degrees of freedom. Precision control with sub-millimeter accuracy, perfect for assembly lines and research labs.",
    price: 4999,
    rating: 4.6,
    reviewsCount: 38,
    badge: "New",
    cardColor:"#0D3320",

  },
  {
    id: 3,
    name: "DataSync Cloud",
    category: "Software",
    description:
      "Seamlessly sync and manage your data across cloud providers. Supports AWS, Azure, and GCP with end-to-end encryption and real-time conflict resolution.",
    price: 49,
    rating: 4.5,
    reviewsCount: 210,
    badge: "Popular",
    cardColor:"#3A1A6E",

  },
  {
    id: 4,
    name: "ML Training Suite",
    category: "AI",
    description:
      "End-to-end machine learning pipeline tool. From data preprocessing to model deployment, everything in one unified workspace built for teams.",
    price: 199,
    rating: 4.7,
    reviewsCount: 89,
    badge: null,
    cardColor:"#1A3A6E",

  },
  {
    id: 5,
    name: "SmartSensor Kit",
    category: "Hardware",
    description:
      "IoT sensor kit with 12 sensors including temperature, humidity, pressure, and motion. Pre-configured for instant plug-and-play integration.",
    price: 149,
    rating: 4.3,
    reviewsCount: 56,
    badge: "Sale",
    cardColor:"#3A1A0D",

  },
  {
    id: 6,
    name: "CyberShield VPN",
    category: "Security",
    description:
      "Enterprise-grade VPN solution with zero-log policy. Military-grade AES-256 encryption, kill switch, and split tunneling for maximum security.",
    price: 79,
    rating: 4.9,
    reviewsCount: 305,
    badge: "Top Rated",
    cardColor:"#0D1B3E",

  },
];


const categories = ["All", "Software", "AI", "Hardware", "Robotics", "Security"];

const ProductsPage = () => {
  const [viewMode, setViewMode] = useState("grid");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const addToCart = (product) => {
    console.log(product);
  };

  const filteredProducts = productsArray.filter(
    (product) => selectedCategory === "All" || product.category === selectedCategory
  );

   return (
    <>
    <div>
      <StyleDivHeader >
        <h1>Our Products</h1>
        <p>Explore our range of software, AI tools, hardware kits, and robotics solutions built<br/> for modern teams.</p>
      </StyleDivHeader>
<BackgroundColor >
        <div className="container">
          
        <FilterBar>
          <CategoryButtons>
            {categories.map((cat) => (
              <button
                key={cat}
                className={selectedCategory === cat ? "active" : ""}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </CategoryButtons>


          <ViewToggle>
            <button
              className={viewMode === "grid" ? "active" : ""}
              onClick={() => setViewMode("grid")}
            >
              <LuLayoutGrid />
            </button>
            <button
              className={viewMode === "list" ? "active" : ""}
              onClick={() => setViewMode("list")}
            >
              <BsListUl />
            </button>
          </ViewToggle>
        </FilterBar>
        </div>
<HrMargin/>
        </BackgroundColor>
<DivContainer >
<div className="container">
      <PageContainer>
        <ResultsCount>{filteredProducts.length} products found</ResultsCount>

        {filteredProducts.length === 0 && (
          <p>No products found</p>
        )}

        {viewMode === "grid" ? (
          <ProductsGrid >
            {filteredProducts.map((product) => (
              <ProductCardGrid
                key={product.id}
                product={product}
                onAddToCart={addToCart}
              />
            ))}
          </ProductsGrid>
        ) : (
          <ProductsList>
            {filteredProducts.map((product) => (
              <ProductCardList
                key={product.id}
                product={product}
                onAddToCart={addToCart}
              />
            ))}
          </ProductsList>
        )}
      </PageContainer>
      </div>
      </DivContainer>
    </div> 
    <HrMargin/>
      <Footer/> 
</>

  );
};

export default ProductsPage;
