import { useState } from "react";
import { useFormik } from "formik";
import { signupSchema } from "./schema";
import { InputTypes } from "../../constants/enums";
import CustomButton from "../../components/common/Button";
import {
  RegisterHero,
  RegisterForm,
  NameRow,
  HelperText,
  ALink,
  SocialRow,
  HrMargin,
} from "./style";
import { FaFacebookF } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";
import InputProvider from "../../components/common/inputs/input-provider";
import Footer from "../Footer";


const Register = () => {
  
    const [submittedValues, setSubmittedValues] = useState(null);

    const formik = useFormik ({
      initialValues: {

       fName: "",
       lName: "",
       email: "",
       phone: "",
       password: "",
       confirmPassword: "",
       isAgreed: false,
      },
      validationSchema: signupSchema,

      onSubmit: (values) => {

        setSubmittedValues(values);
    },
    });

     const connectField = (name) => ({

    name,
    fieldValue: formik.values[name],
    onChangeFunction: (value) => formik.setFieldValue(name, value),
    onBlurFunction: () => formik.setFieldTouched(name, true),
    errorMessage: formik.touched[name] && formik.errors[name],

  });


 const fields = [
    {
      type: InputTypes.TEXT,
      fieldLabel: "First Name",
      placeholder: "John",
      ...connectField("fName"),
    },
    {
      type: InputTypes.TEXT,
      fieldLabel: "Last Name",
      placeholder: "Doe",
      ...connectField("lName"),
    },
    {
      type: InputTypes.EMAIL,
      fieldLabel: "Email Address",
      placeholder: "you@example.com",
      ...connectField("email"),
    },
    
    {
      type: InputTypes.PASSWORD,
      fieldLabel: "Password",
      placeholder: "Min. 6 characters",
      ...connectField("password"),
    },
    {
      type: InputTypes.PASSWORD,
      fieldLabel: "Confirm password",
      placeholder: "Repeat your password",
      ...connectField("confirmPassword"),
    },
    {
      type: InputTypes.CHECKBOX,
      fieldLabel: (
        <>
          I agree to the{" "}
          <a href="/terms-of-service">Terms of Service</a>{" "}
          and{" "}
          <a href="/privacy-policy">Privacy Policy</a>
        </>
      ),
      ...connectField("isAgreed"),
    },
  ];

  return (
  <>
    <RegisterHero>
      <RegisterForm>
        <h3>Create Account</h3>
        <p>Join DKUST today — it's free</p>

        <form onSubmit={formik.handleSubmit}>
          <NameRow>
            {fields.slice(0, 2).map((item) => (
              <InputProvider key={item.name} itemObject={item} />
            ))}
          </NameRow>

          {fields.slice(2).map((item) => (
            <InputProvider key={item.name} itemObject={item} />
          ))}

          <CustomButton 
          type="submit"
          label="CREATE ACCOUNT"
          variant="primary"
          fullWidth="100%"
          />
        </form> 



        {submittedValues ? (
          <pre>{JSON.stringify(submittedValues, null, 2)}</pre>
        ) : null}

         <HelperText>or sign up with</HelperText>
         <SocialRow>
          <CustomButton 
          onClickFunction={() => console.log("Google")}
          label="Google" 
         variant ="white"
          icon={FcGoogle}
          fullWidth="100%"
          />


         <CustomButton onClickFunction={() => console.log("Facebook")} 
         label="Facebook"
          variant ="white"
         icon={FaFacebookF }

          />
          
        </SocialRow>
        <HelperText>
          Already have an account? <a href="/login">Sign in</a>
        </HelperText>
      </RegisterForm>

      <ALink>
        <a href="home">Back to Home</a>
      </ALink>
    </RegisterHero>
   <HrMargin/>
    <Footer/>
    </>
  );
};

export default Register;
