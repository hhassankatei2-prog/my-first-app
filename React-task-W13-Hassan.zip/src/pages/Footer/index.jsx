import { useState } from "react";
import { FiSend } from "react-icons/fi";
import { LuFacebook } from "react-icons/lu";
import { TbBrandTwitter } from "react-icons/tb";
import { SlSocialLinkedin } from "react-icons/sl";
import { FaInstagram } from "react-icons/fa";
import { DivBcColor } from "./style";
const Footer = () => {
  const [emailAddress, setEmailAddress] = useState("");
  const handleSubscribe = (event) => {
    setEmailAddress("");
  };
  return (
    <DivBcColor>
    <footer className="footer container" >
      <div className="footer-container">

        {/* Contact Detail */}
        <div className="footer-column">
          <div className="CONTACT-DETAIL">
            <h4>CONTACT DETAIL</h4>

            <p>123 Business Street,Suite 100,</p>
            <p>New York,NY 10001</p>
            <p>Phone: +1 234 567 8900</p>
            <p>Email: info@dkust.com</p>
          </div>
        </div>

        {/* Quick Links */}
        <div className="footer-column">
          <h4>QUICK LINKS</h4>

          <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Portfolio</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contact Us</a></li>
          </ul>
        </div>

        {/* Our Services */}
        <div className="footer-column">
          <h4>OUR SERVICES</h4>

          <ul>
            <li><a href="#">Web Development</a></li>
            <li><a href="#">Machine Learning</a></li>
            <li><a href="#">Robotics</a></li>
            <li><a href="#">Industrial Consulting</a></li>
            <li><a href="#">Data Analytics</a></li>
          </ul>
        </div>

        {/* Subscribe Newsletter */}
        <div className="footer-column">
          <h4>SUBSCRIBE NEWSLETTER</h4>

          <p>Get the latest updates and news.</p>

          <div >
            <input
            className="newsletter-input"
              type="email"
              placeholder="Email Address"
              value={emailAddress}
              onChange={(event) => setEmailAddress(event.target.value)}
            />

            <button className="newsletter-btn" onClick={handleSubscribe}>
              <FiSend size={12} color="white" />
            </button>
          </div>
        </div>

      </div>

      <div className="footer-bottom">
        <p>Copyright © DKUST | All Rights Reserved</p>
        <p>Created by :Hassan Katei</p>
        <div className="footer-social">
          <a href="#" target="_blank" rel="noopener noreferrer">
            <LuFacebook size={13} />
          </a>
          <a href="#" target="_blank" rel="noopener noreferrer">
            <TbBrandTwitter size={13} />
          </a>
          <a href="#" target="_blank" rel="noopener noreferrer">
            <SlSocialLinkedin size={13}  />
          </a>
          <a href="#" target="_blank" rel="noopener noreferrer">
            <FaInstagram size={13}  />
          </a>
        </div>
      </div>
    </footer>
    </DivBcColor>
  );
};

export default Footer;