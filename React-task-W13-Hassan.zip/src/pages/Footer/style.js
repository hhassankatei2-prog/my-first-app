import styled from "styled-components";

export const DivBcColor = styled.div`
  background-color: var(--color-bg-light2);
`;
