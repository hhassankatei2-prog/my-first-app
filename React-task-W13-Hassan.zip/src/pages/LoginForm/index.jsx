import { useState } from "react";
import { FaFacebook } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";
import Footer from "../Footer";
import InputProvider from "../../components/common/inputs/input-provider";
import { InputTypes } from "../../constants/enums";
import { useFormik } from "formik";
import { signupSchema } from "./schema";
import CustomButton from "../../components/common/Button";
import { LoginStyle, PasswordField } from "./style";
import { useDispatch,useSelector } from "react-redux";
import { login } from "../../store/authSlice";
import { Link, useNavigate } from "react-router-dom";
import { FaCheck } from "react-icons/fa";
// import {login} from 
const LoginForm = () => {


  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
const [submittedValues, setSubmittedValues] = useState(null);
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log({ email, password, rememberMe });
    console.log("كييييييييييفك كوتش");
    setEmail("");
    setPassword("");
   setRememberMe(false);
  };

  const handleForgotPassword = (event) => {
    event.preventDefault();
    console.log("Forgot password clicked");
  };

  const handleGoogleSignIn = () => {
    console.log("Sign in with Google");
  };

  const handleFacebookSignIn = () => {
    console.log("Sign in with Facebook");
  };

const formik = useFormik ({
initialValues : {
  email: "",
  password:"",

},
validationSchema : signupSchema,

 onSubmit: (values) => {

       setSubmittedValues (values);
       dispatch(login(values.email));
    },

});

     const connectField = (name) => ({

    name,
    fieldValue: formik.values[name],
    onChangeFunction: (value) => formik.setFieldValue(name, value),
    onBlurFunction: () => formik.setFieldTouched(name, true),
    errorMessage: formik.touched[name] && formik.errors[name],

  });
const fields = [
{
      type: InputTypes.EMAIL,
      fieldLabel: "Email Address",
      placeholder: "you@example.com",
      ...connectField("email"),
    },

{
      type: InputTypes.PASSWORD,
      fieldLabel: "Password",
      placeholder: "Min. 6 characters",
      ...connectField("password"),
    },
  {
      type: InputTypes.CHECKBOX,
      fieldLabel: "Remember me",
      ...connectField("isAgreed"),
    },
  ];
const dispatch = useDispatch();
const user = useSelector ((state) => state.auth.user);
const navigate = useNavigate();

  return (
    <LoginStyle>
      
     {user ? 
     (<section className="login-hero-user">
      
        <div className="login-form-user">
            <h2>Welcome Back</h2>
            <p>Sign in to your DKUST account</p>
          <div className="login-success-card">
            <div className="success-icon"><FaCheck size={20}/></div>
            <h2>Login Successful!</h2>
            <p>You have been signed in successfully.</p>
            <CustomButton
              label="Go to Home"
              variant="primary"
              fullWidth="160px"
              onClickFunction={() => navigate("/home")}
            />
            </div>
          </div>
          
          <Link to="/home" id="forgotPassword">
          Back to Home
        </Link>
        </section>
      ) 
      :
      (
      
      <section className="login-hero">
        <div className="login-hero-content">
          {/* onSubmit={handleSubmit} */}
          <form onSubmit={formik.handleSubmit} className="login-form" >
            <h2>Welcome Back</h2>
            <p>Sign in to your DKUST account</p>
            

           { fields.slice(0,1).map((ite)=> (
            <InputProvider key={ite.name} itemObject={ite} />
            
            ))}

            <PasswordField>
              {fields.slice(1, 2).map((ite) => (
                <InputProvider key={ite.name} itemObject={ite} />
              ))}
            </PasswordField>

        
             {fields.slice(2).map((item) => (
            <InputProvider key={item.name} itemObject={item} />
            
          ))}

            <CustomButton 
          type="submit"
          label="SIGN IN"
          variant="primary"
          fullWidth="100%"
          />


            <p>or continue with</p>
            <div className="social-login">
              <button type="button" onClick={handleGoogleSignIn}>
                <FcGoogle size={20}/>
                Google
              </button>

              <button type="button" onClick={handleFacebookSignIn}>
                <FaFacebook size={20} color="blue" />
                Facebook
              </button>
            </div>
            <p>
              Don't have an account? <a href="#">Sign up</a>
            </p>
          </form>
        </div>
        <Link to="/home" id="forgotPassword">
          Back to Home
        </Link>
      </section>
)}
      <section className="gaq">
        <div className="gaq-content">
          <h2>Generally Asked Question</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor<br />
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam
            quis<br />
            nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
          </p>
        </div>

        <div className="accordion" id="faqAccordion">
          <div className="accordion-item">
            <h2 className="accordion-header">
              <button
                className="accordion-button"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse1"
              >
                Accordion Item #1
              </button>
            </h2>
            <div
              id="collapse1"
              className="accordion-collapse collapse"
              data-bs-parent="#faqAccordion"
            >
              <div className="accordion-body">....</div>
            </div>
          </div>

          <div className="accordion-item">
            <h2 className="accordion-header">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse2"
              >
                Accordion Item #2
              </button>
            </h2>
            <div
              id="collapse2"
              className="accordion-collapse collapse"
              data-bs-parent="#faqAccordion"
            >
              <div className="accordion-body">.....</div>
            </div>
          </div>

          <div className="accordion-item">
            <h2 className="accordion-header">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse3"
              >
                Accordion Item #3
              </button>
            </h2>
            <div
              id="collapse3"
              className="accordion-collapse collapse"
              data-bs-parent="#faqAccordion"
            >
              <div className="accordion-body">.....</div>
            </div>
          </div>
        </div>
      </section>
      <Footer/>
    </LoginStyle>
  );
};

export default LoginForm;
