import styled from "styled-components";

export const ButtonStyles = styled.div`
  width: ${(props) => props.fullWidth || "100%"};
  button {
    width: 100%;

    background-color: ${(props) =>
      props.backgroundColor ||
      (props.variant === "white"
        ? "var(--color-bg-white)"
        : "var(--color-accent)")};

    color: ${(props) =>
      props.color ||
      (props.variant === "white"
        ? "var(--color-text-body)"
        : "var(--color-bg-white)")};

    border: 1px solid
      ${(props) =>
        props.border ||
        (props.variant === "white"
          ? "var(--color-text-muted)"
          : "var(--color-accent)")};

    border-radius: 8px;
    padding: ${(props) => props.padding || "10px 14px"};
    font-weight: 600;
    display: flex;
    gap: 2px;
    justify-content: center;
    align-items: center;
    outline: none;
    transition:
      background-color 0.2s ease,
      transform 0.2s ease;
    white-space: nowrap;
    font-size: 0.85rem;
    .icon {
      font-size: 1rem;
    }
    &:hover {
      background-color: ${(props) =>
        props.backgroundColorHover ||
        (props.variant === "white"
          ? "var(--color-bg-light)"
          : "var(--color-accent-hover2)")};
      border: 1px solid
        ${(props) =>
          props.borderHover ||
          (props.variant === "white"
            ? "var(--color-accent)"
            : "var(--color-accent-hover2)")};

      outline: none;
      color: ${(props) =>
        props.colorHover ||
        (props.variant === "white"
          ? "var(--color-accent)"
          : "var(--color-bg-white)")};
    }
  }
`;
